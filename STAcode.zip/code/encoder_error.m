function error_rate = encoder_error(out_out_enc,input)

[dim_size pattern_n] = size(out_out_enc);

sqr_err = sum((out_out_enc - input).^2)/dim_size;
error_rate = mean(sqr_err);
return;

end