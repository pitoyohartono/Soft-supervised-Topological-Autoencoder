function drawmap_unspervisedtext(input,teacher_sig,input_scale,neighbor_scale)
     global pos;
     global win_list;
     global out_out_cls;
     
     [dum mid_n] = size(pos);
     [pattern_n class_n] = size(teacher_sig);
     
     mid_neuron_trace = zeros(mid_n,class_n);
     
     forwardprop_for_draw(input,teacher_sig,input_scale,neighbor_scale);
     
     for i=1:pattern_n
         mid_neuron_trace(win_list(1,i),vec2ind(teacher_sig(i,:)')) = mid_neuron_trace(win_list(1,i),vec2ind(teacher_sig(i,:)')) + 1;
     end
         
     figure
     
     for i=1:mid_n
         activity = sum(mid_neuron_trace(i,:));
         if(activity > 0)
          %   [dummy class_idx] = max(mid_neuron_trace(i,:));
            for j=1:class_n
                if mid_neuron_trace(i,j) > 0
                    class_idx = j;
                    for k=1:mid_neuron_trace(i,j)
                        switch class_idx
                            case 1
                                setting = 'r';
                            case 2
                                setting = 'b';
                            case 3
                                setting = 'g';
                            case 4
                                setting = 'k';
                            case 5
                                setting = 'm';
                            case 6
                                setting = 'c';
                            case 7
                                setting = 'g';
                            case 8
                                setting = 'k';
                            case 9
                                setting = 'r';
                            case 10
                                setting = 'b';
                        end
                        c=cellstr(num2str(class_idx-1));
                        pos_rand = pos(:,i) + (rand(2,1)*0.4-0.2);
                        %scatter(pos_rand(1,1),pos_rand(2,1),100,setting,'filled');
                        text(pos_rand(1,1),pos_rand(2,1),c,'FontSize',15,'Color',setting);
                        hold on
                    end
                end 
            end
       end
     end 
     
     xlim([0 sqrt(mid_n)+1]);
     ylim([0 sqrt(mid_n)+1]);
     axis square
     
    % win_list(i): which hidden neuron pattern i belongs to.
    % win_list is calculated in forwardprop_for_draw(input,teacher,input_scale,neighbor_scale)
    
    class_similarity_measure(win_list,input,teacher_sig,mid_n,class_n);
     
    
    
    return;
     
end
