function modify_net(input,teacher,eta1,eta2)
    global pos;
    global ref_vector;
    global weight_vector_enc;
    global weight_vector_cls;
    
    global out_bias_enc;
    global out_bias_cls;
    
    global hidden_out;
    global out_out_enc;
    global out_out_cls;
    
    global out_enc;
    global out_cls;

    
    global dif_out_enc;
    global dif_out_cls;
    
    global dist_from_input;
    global dist_from_winner;
    
    global kappa;
    
    
    
    
    [pattern_n dim_n] = size(input);
    [mid_n in_n] = size(ref_vector);
    [dummy out_n] = size(teacher);
    
    weight_modification_enc = zeros(in_n,mid_n);
    weight_modification_cls = zeros(out_n,mid_n);
    
    bias_modification_enc = zeros(in_n,1);
    bias_modification_cls = zeros(out_n,1);
    
    ref_vector_modification = zeros(mid_n,in_n);
    
    
    delta_out_enc = (out_out_enc - input') .* dif_out_enc;
    delta_out_cls = (out_out_cls - teacher') .* dif_out_cls;
    
    modify_intense =(((1-kappa)*(1/out_enc)*(weight_vector_enc' * delta_out_enc) + (kappa * (1/out_cls)*(weight_vector_cls' * delta_out_cls))).* hidden_out')';
    
    for i=1:pattern_n
        weight_modification_enc = weight_modification_enc - eta1*(delta_out_enc(:,i) * hidden_out(i,:));
        bias_modification_enc = bias_modification_enc - eta1*delta_out_enc(:,i)*(-1);
        
        weight_modification_cls = weight_modification_cls - eta1*(delta_out_cls(:,i) * hidden_out(i,:));
        bias_modification_cls = bias_modification_cls - eta1*delta_out_cls(:,i)*(-1);
        
        ref_input_dif = repmat(input(i,:)',1,mid_n) - ref_vector';
        ref_vector_modification = ref_vector_modification - eta2*(repmat(modify_intense(i,:),in_n,1).*ref_input_dif)';
    end
     
    weight_vector_enc = weight_vector_enc + ((1-kappa)*((1/pattern_n)*weight_modification_enc));
    out_bias_enc = out_bias_enc + ((1-kappa)*(1/pattern_n)*bias_modification_enc);
    
    weight_vector_cls = weight_vector_cls + (kappa*((1/pattern_n)*weight_modification_cls));
    out_bias_cls = out_bias_cls +( kappa*(1/pattern_n)*bias_modification_cls);
    
    ref_vector = ref_vector + (1/pattern_n)*ref_vector_modification;
    
    