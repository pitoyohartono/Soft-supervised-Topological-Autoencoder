function forwardprop_for_draw_test(input,teacher,input_scale,neighbor_scale)
    global pos;
    global ref_vector;
    global weight_vector_enc;
    global out_bias_enc;
    global weight_vector_cls;
    global out_bias_cls;
    
    global hidden_out;
    global out_out_enc;
    global out_out_cls_test;
    
    
    global dif_out;
    
    
    global dist_from_input;
    global dist_from_winner;
    global win_list
  
        
    [pattern_n dim_n] = size(input);
    [mid_n in_n] = size(ref_vector);
    [dummy out_enc] = size(teacher);
    
    dist_from_input = zeros(pattern_n,mid_n);
    dist_from_winner = zeros(pattern_n,mid_n);
    win_list = zeros(1,pattern_n);
    
    
    for i=1:pattern_n
        dist_from_input(i,:) = sum(((ref_vector'-repmat(input(i,:)',1,mid_n)).^2)/input_scale); %distance of the i-th input to all the mid neuron
        [dummy  win_list(1,i)]=min(dist_from_input(i,:)');   %winner against the i-th input

        dist_from_winner(i,:) = sum((pos-pos(:,win_list(1,i))).^2);
    end
    neighbor_intens = exp((-1/neighbor_scale)*dist_from_winner);
    
    hidden_out = neighbor_intens .* exp(-1*dist_from_input);
   
    
    
    % logsig
    out_out_enc = 1./(1+exp((-1/10)*(weight_vector_enc * hidden_out'-repmat(out_bias_enc,1,pattern_n))));  %for fashion 20
    out_out_cls_test = 1./(1+exp((-1/10)*(weight_vector_cls * hidden_out'-repmat(out_bias_cls,1,pattern_n))));
    
    
   
    
    
    
    