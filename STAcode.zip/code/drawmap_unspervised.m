function error_rate = drawmap_unspervised(input,teacher_sig,input_scale,neighbor_scale)
     global pos;
     global win_list;
     global out_out_cls;
     
     global problem;
     global kappa;
     
     [dum mid_n] = size(pos);
     [pattern_n class_n] = size(teacher_sig);
     
     mid_neuron_trace = zeros(mid_n,class_n);
     
     forwardprop_for_draw(input,teacher_sig,input_scale,neighbor_scale);
     
     for i=1:pattern_n
         mid_neuron_trace(win_list(1,i),vec2ind(teacher_sig(i,:)')) = mid_neuron_trace(win_list(1,i),vec2ind(teacher_sig(i,:)')) + 1;
     %     mid_neuron_trace(win_list(1,i),vec2ind(out_out_cls(:,i))) = mid_neuron_trace(win_list(1,i),vec2ind(out_out_cls(:,i))) + 1;
     end
         
     mapfig=figure;
     
     for i=1:mid_n
         activity = sum(mid_neuron_trace(i,:));
         if(activity > 0)
          %   [dummy class_idx] = max(mid_neuron_trace(i,:));
            for j=1:class_n
                if mid_neuron_trace(i,j) > 0
                    class_idx = j;
                    for k=1:mid_neuron_trace(i,j)
                        switch class_idx
                            case 1
                                setting = 'ro';
                            case 2
                                setting = 'bs';
                            case 3
                                setting = 'gd';
                            case 4
                                setting = 'kp';
                            case 5
                                setting = 'mv';
                            case 6
                                setting = 'co';
                            case 7
                                setting = 'yh';
                            case 8
                                setting = 'k^';
                            case 9
                                setting = 'r>';
                            case 10
                                setting = 'b<';
                        end
                        pos_rand = pos(:,i) + (rand(2,1)*0.4-0.2);
                        scatter(pos_rand(1,1),pos_rand(2,1),100,setting,'filled');
                        hold on
                    end
                end 
            end
       end
     end 
     
     xlim([0 sqrt(mid_n)+1]);
     ylim([0 sqrt(mid_n)+1]);
    % title('Learning Map');
     axis square
     
     
     dirmapname = sprintf('./flatneighbormaps/fromApril27/%s',problem);
     if (~exist(dirmapname,'dir'))
         mkdir(dirmapname);
     end
     
     if kappa == 1
       filename = sprintf('./flatneighbormaps/fromApril27/%s/%skappa%d.fig',problem,problem,kappa);
       filenameeps = sprintf('./flatneighbormaps/fromApril27/%s/%skappa%d',problem,problem,kappa);
     else
       filename = sprintf('./flatneighbormaps/fromApril27/%s/%skappa0%d.fig',problem,problem,kappa*10); 
       filenameeps = sprintf('./flatneighbormaps/fromApril27/%s/%skappa0%d',problem,problem,kappa*10); 
     end
     saveas(mapfig,filenameeps,'epsc');
     saveas(mapfig,filename);
    
    
     
     
     [dummy idx_class] = max(out_out_cls);
     [dummy idx_teacher] = max(teacher_sig');
     
     dif = sum(sign(abs(idx_class - idx_teacher)));
     
     error_rate = (dif/pattern_n)*100;
     
     class_similarity_measure(win_list,input,teacher_sig,mid_n,class_n);
     
     return;
     
end
