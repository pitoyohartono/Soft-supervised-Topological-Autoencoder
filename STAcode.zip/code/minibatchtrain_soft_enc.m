function minibatchtrain_soft_enc(input,teacher,sigma_start,sigma_end,input_scale,out_enc,epoch_n,mini_batch_num)
    global hidden_out;
    global error_end;
    global  eta1_start;
    global  eta2_start;
    
    global error_log;
    
    
    
    [pattern_n dim_n] = size(input);
    indices = crossvalind('kfold',pattern_n,mini_batch_num);
    
    error_log = zeros(epoch_n,1);
    active_log = zeros(epoch_n,1);
    
    flat_rate = 0.8;
    
    for i=1:epoch_n
        mini_batch_index = rem(i,mini_batch_num)+1;
        minibatch = (indices==mini_batch_index);
        input_batch = input(minibatch,:);
        teacher_batch = teacher(minibatch,:);
        
        %scale = sigma_start * (sigma_end/sigma_start)^(count/target_count);
       % neighbor_scale = sigma_end + (sigma_start-sigma_end)*((epoch_n - i)/epoch_n).^2;
         if (i < flat_rate * epoch_n)
            neighbor_scale = sigma_end + 0.5*(sigma_start-sigma_end) * (1+cos((i-1)*pi/(flat_rate*epoch_n)));
         else
            neighbor_scale = sigma_end;
         end
        
        %eta1 = eta1_start * (epoch_n - (i-1))/epoch_n;
        %eta2 = eta2_start * (epoch_n - (i-1))/epoch_n;
        
         eta1 =  eta1_start + 0.5*( eta1_start-(0.01* eta1_start)) * (1+cos((i-1)*pi/epoch_n));
         eta2 =  eta2_start + 0.5*( eta2_start-(0.01* eta2_start)) * (1+cos((i-1)*pi/epoch_n));
         
         error_log(i,1) = forwardprop(input_batch,teacher_batch,input_scale,neighbor_scale);
         active_log(i,1) = mean(sum((hidden_out > 0.1)'));
         
         if(error_log(i,1) < error_end)
             break;
         end
         
         modify_net(input_batch,teacher_batch,eta1,eta2);
    end
    
    
    figure
    plot(error_log);
    title('Learning Curve');
    ylabel('MSE');
    xlabel('epochs');
    
    figure
    plot(active_log);
    title('Num of active hidden neurons');
    ylabel('Num active hidd');
    xlabel('epochs');
    
    
end
