clear all;

global input;
global teacher_cls;

global pos;
global ref_vector;
global weight_vector_enc;
global out_bias_enc;
global weight_vector_cls;
global out_bias_cls;

global hidden_out;
global out_out_enc;
global out_out_cls;

global out_enc;
global out_cls;

global dif_out;


global dist_from_input;
global dist_from_winner;

global csi;

 global  eta1_start;
 global  eta2_start;

global problem;

global kappa;

global error_end;




problem = 'irisfull';
filename = sprintf('../data/%s.txt',problem);
pattern_n = 150;

in_n = 4;
%mid_n = floor(sqrt(pattern_n))^2;
mid_n = 12*12;
out_enc = in_n;
out_cls = 3;

eta1_start = 1;
eta2_start = 1;

error_end = 0.001; %terminate below this point

kappa =1; %the error ration of encoding error and class error (between 0 - 1)
             %kappa=1 for classifier, 0 for autoencoder

input_scale = 4*in_n;  % the larger the more distinguishable ?
    
%for neighborhood function
sigma_start =20;
sigma_end =2; %set a little bit bigger to spread the map, generalization

epoch_n = 2000;
mini_batch_num = 1;

rng(1224); %random seed

%learning file
input_temp = zeros(pattern_n,in_n);
input = zeros(pattern_n,in_n);
teacher_cls = zeros(pattern_n,out_cls);

% initialize crsom
pos = zeros(2,mid_n);
row_size = sqrt(mid_n);
for i=0:mid_n-1
   pos(1,i+1) = floor(i/row_size) + 1;
   pos(2,i+1) = rem(i,row_size) + 1;
end
ref_vector = rand([mid_n in_n]) * 0.2-0.1;

%initialize weight;
weight_vector_enc = rand([in_n mid_n]) *  0.2-0.1;
out_bias_enc = rand([in_n 1]) * 0.2-0.1;

if kappa ~= 0
    weight_vector_cls = rand([out_cls mid_n]) *  0.2-0.1;
    out_bias_cls = rand([out_cls 1]) * 0.2-0.1;
else
    weight_vector_cls = zeros(out_cls,mid_n);
    out_bias_cls = zeros(out_cls,1);
end


fid=fopen(filename,'rt');
for i=1:pattern_n
    input_temp(i,:)=fscanf(fid,'%f',in_n);
    teacher_cls(i,:)=fscanf(fid,'%d',out_cls);
end
fclose(fid);
teacher_enc = input;

%standardization
for i=1:in_n
    max_element = max(input_temp(:,i));
    min_element = min(input_temp(:,i));
  % input(:,i) = 2*((input_temp(:,i)-min_element)/(max_element-min_element))-1;
    input(:,i) = ((input_temp(:,i)-min_element)/(max_element-min_element));
  %  input(:,i) = input_temp(:,i);   %for MNIST, normal and GEMS use this
end



minibatchtrain_soft_enc(input,teacher_cls,sigma_start,sigma_end,input_scale,out_enc,epoch_n,mini_batch_num);

error_rate = drawmap_unspervised(input,teacher_cls,input_scale,sigma_end)
%drawmap_unspervisedtext(input,teacher_cls,input_scale,sigma_end)

recon_error = encoder_error(out_out_enc,input');

error_inf = sprintf('classification error: %f, reconstruction error: %f, csi: %f\n',error_rate,recon_error,csi);
disp(error_inf)

