This is the sample program for STA trained on iris.

STArun.m is the main program while irisfull.txt contains the training data.

for this program, kappa, the mixing coefficient is set to 1.
It can be changed by changing the variable kappa in line 55 of STArun.m