function class_similarity_measure(win_list,input,teacher_sig,mid_n,class_n)
   global pos;
   global csi;
   
    pattern_n = length(win_list);
    
    hidden_class = zeros(mid_n,class_n); %hidden_class(i,j): the number of class j representated by hidden neuron i;
    
    for i=1:pattern_n
        hidden_class(win_list(1,i),vec2ind(teacher_sig(i,:)')) = hidden_class(win_list(1,i),vec2ind(teacher_sig(i,:)')) + 1;    
    end
    
   
    
    row_size = sqrt(mid_n);
    
    
    class_similarity = zeros(1,pattern_n);
    
    only_win = 0;
    trace_denominator = 0;
    sum_rate_same_class = 0;
   
    for i=1:pattern_n
        
        num_same_class = 0;
        num_all_class = 0;
        
        trace_same_class_rate = 0;
        % WINNER
        rate_class_win = hidden_class(win_list(1,i),vec2ind(teacher_sig(i,:)'))/sum(hidden_class(win_list(1,i),:));
        denominator = 1;
        %only_win
        only_win = only_win + rate_class_win;
        
        num_same_class = num_same_class + hidden_class(win_list(1,i),vec2ind(teacher_sig(i,:)'));
        num_all_class = num_all_class + sum(hidden_class(win_list(1,i),:));
        
        
        
        % neighbor to the LEFT
        rate_class_left = 0;
        pos_left = pos(2,win_list(1,i))-1;
        if pos_left > 0
           neighbor_left = win_list(1,i)-1;
           if hidden_class(neighbor_left,vec2ind(teacher_sig(i,:)')) > 0
                rate_class_left = hidden_class(neighbor_left,vec2ind(teacher_sig(i,:)'))/sum(hidden_class(neighbor_left,:));
                denominator = denominator + 1;    
           end
           num_same_class = num_same_class + hidden_class(neighbor_left,vec2ind(teacher_sig(i,:)'));
           num_all_class = num_all_class + sum(hidden_class(neighbor_left,:));
        end
        
        
         
        %neighbor to the RIGHT
        rate_class_right = 0;
        pos_right = pos(2,win_list(1,i))+1;
        if pos_right < row_size
            neighbor_right = win_list(1,i)+1;
            if hidden_class(neighbor_right,vec2ind(teacher_sig(i,:)'))>0
                rate_class_right = hidden_class(neighbor_right,vec2ind(teacher_sig(i,:)'))/sum(hidden_class(neighbor_right,:));
                 denominator = denominator + 1;
                 
            end
            num_same_class = num_same_class + hidden_class(neighbor_right,vec2ind(teacher_sig(i,:)'));
            num_all_class = num_all_class + sum(hidden_class(neighbor_right,:));
        end
       
        
         
        %neighbor up 
        rate_class_up = 0;
        pos_up = pos(1,win_list(1,i))-1;
        if pos_up > 0
            neighbor_up = win_list(1,i) - row_size;
            if hidden_class(neighbor_up,vec2ind(teacher_sig(i,:)'))>0
                rate_class_up = hidden_class(neighbor_up,vec2ind(teacher_sig(i,:)'))/sum(hidden_class(neighbor_up,:));
                denominator = denominator + 1;
            end
            num_same_class = num_same_class + hidden_class(neighbor_up,vec2ind(teacher_sig(i,:)'));
            num_all_class = num_all_class + sum(hidden_class(neighbor_up,:));
        end
        
        
        
        %neighbor down
        rate_class_down = 0;
        pos_down = pos(1,win_list(1,i))+1;
        if pos_down < row_size
            neighbor_down = win_list(1,i) + row_size;
            if hidden_class(neighbor_down,vec2ind(teacher_sig(i,:)'))>0
                rate_class_down = hidden_class(neighbor_down,vec2ind(teacher_sig(i,:)'))/sum(hidden_class(neighbor_down,:));
                denominator = denominator + 1; 
            end
            num_same_class = num_same_class + hidden_class(neighbor_down,vec2ind(teacher_sig(i,:)'));
            num_all_class = num_all_class + sum(hidden_class(neighbor_down,:));
        end
        
        
        
        
        
        class_similarity(1,i) = (rate_class_win + rate_class_left + rate_class_right + rate_class_up + rate_class_down)/denominator;
        
        trace_denominator = trace_denominator + denominator;
       
        sum_rate_same_class = sum_rate_same_class + (num_same_class/num_all_class);
    end
    
    
    
    win_similarity = only_win/pattern_n;
    
    av_denominator = trace_denominator/pattern_n;
    
    av_rate_same_class = sum_rate_same_class/pattern_n;
   
    
    csi =  av_rate_same_class;
    return;

end